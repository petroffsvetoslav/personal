# Prerequisites
* allow ssh from your IP in SG https://eu-west-1.console.aws.amazon.com/ec2/v2/home?region=eu-west-1#SecurityGroup:groupId=sg-09abe519192c78d64
* delete contents of users.txt
* place new users in users.txt (1 user per line)
# Run playbook
* ansible-playbook -i hosts.ini --private-key <vius-devops.pem location> playbook.yml
* after playbook executes, remove your IP from SG https://eu-west-1.console.aws.amazon.com/ec2/v2/home?region=eu-west-1#SecurityGroup:groupId=sg-09abe519192c78d64
# Info
* .tar.gz of user .conf files will be placed in devops-terraform/vpn/prod/create_accounts/VPN-configs/54.75.163.7/home/ubuntu/configs.tar.gz
* send out .conf as per contents of your users.txt file (.conf file will have same naming as user from users.txt)
* rm -rf ./VPN-configs (so that next time you receive a fully update list of .confs and can select ones you need)
