# Prerequisites
* allow ssh from your IP in SG "vpn"
* delete contents of users.txt
* place new users in users.txt (1 user per line)
# Run playbook
* ansible-playbook -i hosts.ini --private-key <vius-devops.pem location> playbook.yml
* after playbook executes, remove your IP from SG "vpn"
# Info
* .tar.gz of user .ovpn files will be placed in devops-terraform/vpn/create_accounts/VPN-configs/3.253.202.124/home/ubuntu/configs.tar.gz
* send out .ovpn as per contents of your users.txt file (.ovpn file will have same naming as user from users.txt)
* rm -rf ./VPN-configs (so that next time you receive a fully update list of .ovpn files and can select ones you need)
