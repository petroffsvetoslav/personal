#!/bin/bash
mapfile -t users < users.txt
for user in "${users[@]}"; do
    echo "$user"
    pivpn -a nopass -d 365 -n "$user"
done
